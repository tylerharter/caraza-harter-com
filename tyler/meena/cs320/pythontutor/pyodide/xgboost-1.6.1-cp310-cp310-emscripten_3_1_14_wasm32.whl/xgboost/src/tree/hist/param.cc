/*!
 * Copyright 2022 XGBoost contributors
 */
#include "param.h"

namespace xgboost {
namespace tree {
DMLC_REGISTER_PARAMETER(CPUHistMakerTrainParam);
}  // namespace tree
}  // namespace xgboost
